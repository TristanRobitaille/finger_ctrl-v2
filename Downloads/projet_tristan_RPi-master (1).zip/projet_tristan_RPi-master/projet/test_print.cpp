#include "test_print.h"

void print_text (void)
{
	printf("include file worked\n");
}
