#ifndef _TEST_PRINT_H
#define _TEST_PRINT_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

void print_text (void);

#endif
