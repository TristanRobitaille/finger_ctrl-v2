#include <iostream>
#include <cmath>
#include <cstring>
#include <string>
#include "discpp.h"
#include "dislin.h"

void     widget  (void);
void     mysub   (int id,Dislin g);
void     exa     (char *cdev, int iopt,Dislin g);
void     exa_1   (Dislin g);
void     exa_2   (Dislin g);
void     exa_3   (Dislin g);
void     exa_4   (Dislin g);
void     exa_5   (Dislin g);
void     exa_6   (Dislin g);
void     exa_7   (Dislin g);
void     exa_8   (Dislin g);
void     exa_9   (Dislin g);
void     exa_10  (Dislin g);
void     exa_11  (Dislin g);
void     exa12_1 (Dislin g);
void     exa_12  (Dislin g);
void     exa12_2 (Dislin g);
void     exa_13  (Dislin g);
void     exa_14  (Dislin g);
void     ex6_1   (Dislin g);
void     ex10_1  (Dislin g);
void     ex10_2  (Dislin g);
void     ex10_3  (Dislin g);
void     ex11_1  (Dislin g);
void     ex13_1  (Dislin g);
void     ex13_2  (Dislin g);
void     ex13_3  (Dislin g);
void     ex13_4  (Dislin g);
void     ex14_1  (Dislin g);
void     ex14_2  (Dislin g);
