Installation:
=============

The installation procedure is based on cmake and contains nothing
more than the usual procedure:

  # 1. Make a build directory inside Serial directory

    mkdir build

  # 2. Run cmake from inside the build directory

    cd build
    cmake ..

  # 3. Build the example binaries

    make


